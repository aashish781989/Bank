package bank;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.util.Random;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import com.toedter.calendar.JDateChooser;

public class Signup extends JFrame implements ActionListener {
	//Instance variable
	JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13,l14,l15;
	JTextField tfName,tfFatherName,tfEmailAdd,tfAddress,tfCity,tfPinCode,tfState;
	JRadioButton rbnMale,rbnFemale,rbnMarried,rbnUnmarried,rbnOthers;
	JButton btnNext;
	
	JDateChooser dateChooser;
	
	Random r=new Random();
	long randNum=r.nextLong()%9000+1000;
	String number=""+Math.abs(randNum);
	
	//Non Param Constructor
	public Signup() {
		setTitle("New Account Application Form");
		setLayout(null);
		
		l1=new JLabel("Application Form: "+number);
		l1.setFont(new Font("Raleway",Font.BOLD,40));
		l1.setBounds(200,20,600,40);
		add(l1);
		
		l2=new JLabel("Personal Details of Customer:");
		l2.setFont(new Font("Arial",Font.BOLD,25));
		l2.setBounds(230,80,600,30);
		add(l2);
		
		l3=new JLabel("Customer Name:");
		l3.setFont(new Font("Arial",Font.BOLD,20));
		l3.setBounds(100,130,200,30);
		add(l3);
		
		tfName=new JTextField(20);
		tfName.setBounds(320,130,200,30);
		tfName.setFont(new Font("Tahoma",Font.BOLD,10));
		add(tfName);
		
		l4=new JLabel("Father's Name:");
		l4.setFont(new Font("Arial",Font.BOLD,20));
		l4.setBounds(100,160,200,30);
		add(l4);
		
		tfFatherName=new JTextField(20);
		tfFatherName.setBounds(320,160,200,30);
		tfFatherName.setFont(new Font("Tahoma",Font.BOLD,10));
		add(tfFatherName);
		
		l5=new JLabel("DOB:");
		l5.setFont(new Font("Arial",Font.BOLD,20));
		l5.setBounds(100,190,600,30);
		add(l5);
		
		dateChooser=new JDateChooser();
		dateChooser.setForeground(Color.green);
		dateChooser.setBounds(320,190,220,30);
		add(dateChooser);
		
		l6=new JLabel("Gender:");
		l6.setFont(new Font("Arial",Font.BOLD,20));
		l6.setBounds(100,220,600,30);
		add(l6);
		
		rbnMale=new JRadioButton("Male");
		rbnMale.setFont(new Font("Tahoma",Font.BOLD,14));
		rbnMale.setBackground(Color.white);
		rbnMale.setBounds(320,220,70,30);
		add(rbnMale);
		
		rbnFemale=new JRadioButton("Female");
		rbnFemale.setFont(new Font("Tahoma",Font.BOLD,14));
		rbnFemale.setBackground(Color.white);
		rbnFemale.setBounds(420,220,80,30);
		add(rbnFemale);
		
		ButtonGroup bgGender=new ButtonGroup();
		bgGender.add(rbnMale);
		bgGender.add(rbnFemale);
		
		l7=new JLabel("Email Address:");
		l7.setFont(new Font("Arial",Font.BOLD,20));
		l7.setBounds(100,250,600,30);
		add(l7);
		
		tfEmailAdd=new JTextField(20);
		tfEmailAdd.setBounds(320,250,200,30);
		tfEmailAdd.setFont(new Font("Tahoma",Font.BOLD,10));
		add(tfEmailAdd);
		
		l8=new JLabel("Marital Status:");
		l8.setFont(new Font("Arial",Font.BOLD,20));
		l8.setBounds(100,280,600,30);
		add(l8);
		
		rbnMarried=new JRadioButton("Married");
		rbnMarried.setFont(new Font("Tahoma",Font.BOLD,14));
		rbnMarried.setBackground(Color.white);
		rbnMarried.setBounds(320,280,90,30);
		add(rbnMarried);
		
		rbnUnmarried=new JRadioButton("Unmarried");
		rbnUnmarried.setFont(new Font("Tahoma",Font.BOLD,14));
		rbnUnmarried.setBackground(Color.white);
		rbnUnmarried.setBounds(420,280,100,30);
		add(rbnUnmarried);
		
		rbnOthers=new JRadioButton("Others");
		rbnOthers.setFont(new Font("Tahoma",Font.BOLD,14));
		rbnOthers.setBackground(Color.white);
		rbnOthers.setBounds(540,280,90,30);
		add(rbnOthers);
		
		ButtonGroup bgMarital_Status=new ButtonGroup();
		bgMarital_Status.add(rbnMarried);
		bgMarital_Status.add(rbnUnmarried);
		bgMarital_Status.add(rbnOthers);
		
		l9=new JLabel("Address:");
		l9.setFont(new Font("Arial",Font.BOLD,20));
		l9.setBounds(100,310,600,30);
		add(l9);
		
		tfAddress=new JTextField(20);
		tfAddress.setBounds(320,310,200,30);
		tfAddress.setFont(new Font("Tahoma",Font.BOLD,10));
		add(tfAddress);
		
		l10=new JLabel("City:");
		l10.setFont(new Font("Arial",Font.BOLD,20));
		l10.setBounds(100,340,600,30);
		add(l10);
		
		tfCity=new JTextField(20);
		tfCity.setBounds(320,340,200,30);
		tfCity.setFont(new Font("Tahoma",Font.BOLD,10));
		add(tfCity);
		
		l11=new JLabel("Pin Code:");
		l11.setFont(new Font("Arial",Font.BOLD,20));
		l11.setBounds(100,370,600,30);
		add(l11);
		
		tfPinCode=new JTextField(20);
		tfPinCode.setBounds(320,370,200,30);
		tfPinCode.setFont(new Font("Tahoma",Font.BOLD,10));
		add(tfPinCode);
		
		l12=new JLabel("State:");
		l12.setFont(new Font("Arial",Font.BOLD,20));
		l12.setBounds(100,400,600,30);
		add(l12);
		
		tfState=new JTextField(20);
		tfState.setBounds(320,400,200,30);
		tfState.setFont(new Font("Tahoma",Font.BOLD,10));
		add(tfState);
		
		
		btnNext=new JButton("Next");
		btnNext.setFont(new Font ("Arial",Font.BOLD,10));
		btnNext.setBackground(Color.black);
		btnNext.setForeground(Color.white);
		btnNext.setBounds(500,430,80,30);
		add(btnNext);
		btnNext.addActionListener(this);
		
		
		l13=new JLabel("Date:");
		l13.setFont(new Font("Arial",Font.BOLD,20));
		l13.setBounds(100,460,600,30);
		add(l13);
		
		l14=new JLabel("Month:");
		l14.setFont(new Font("Arial",Font.BOLD,20));
		l14.setBounds(100,490,600,30);
		add(l14);
		
		l15=new JLabel("Year:");
		l15.setFont(new Font("Arial",Font.BOLD,20));
		l15.setBounds(100,520,600,30);
		add(l15);
		
		
		getContentPane().setBackground(Color.white);
		setVisible(true);
		setSize(800,700);
		setLocation(400,100);
		
	}

	public static void main(String[] args) {
		Signup object=new Signup();
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		String Form_Number=number;
		String Customer_Name=tfName.getText();
		String Father_Name=tfFatherName.getText();
		String DOB=((JTextField)dateChooser.getDateEditor().getUiComponent()).getText();
		String Gender=null;
		if(rbnMale.isSelected()) {
			Gender="Male";
		}
		else if (rbnFemale.isSelected()) {
			Gender="Female";
		};
		String Email_Address=tfEmailAdd.getText();
		
		String Marital_Status=null;
		if(rbnMarried.isSelected()) {
			Marital_Status="Married";
		}
		else if(rbnUnmarried.isSelected()) {
			Marital_Status="Unmarried";
		}
		else if(rbnOthers.isSelected()) {
			Marital_Status="Others";
		}
		String Address= tfAddress.getText();
		String City= tfCity.getText();
		String Pin_Code= tfPinCode.getText();
		String State= tfState.getText();
		
		try {
		    if (tfName.getText().equals("")) {
		        JOptionPane.showMessageDialog(null, "Please Enter Customer_Name");
		    } else {
		        ConnectionFactory cf = new ConnectionFactory();
		        String query = "INSERT INTO SignUp (Form_Number, Customer_Name, Father_Name, DOB, Gender, Email_Address, Marital_Status, Address, City, Pin_code, State) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		        PreparedStatement ps = cf.con.prepareStatement(query);
		        ps.setString(1, Form_Number);
		        ps.setString(2, Customer_Name);
		        ps.setString(3, Father_Name);
		        ps.setString(4, DOB);
		        ps.setString(5, Gender);
		        ps.setString(6, Email_Address);
		        ps.setString(7, Marital_Status);
		        ps.setString(8, Address);
		        ps.setString(9, City);
		        ps.setString(10, Pin_Code);
		        ps.setString(11, State);
		       int rows = ps.executeUpdate();
		        if (rows > 0) {
		        	setVisible(false);
		            //JOptionPane.showMessageDialog(btnNext, "Data Saved Successfully");
		        	new SignUpTwo(Form_Number).setVisible(true);
		        } else {
		            JOptionPane.showMessageDialog(btnNext, "Failed to Save Data");
		        }
		        
		    }
		} catch (Exception ex) {
		    JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
		    ex.printStackTrace();
		}
		
		
	}

}
