package bank;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
public class Login extends JFrame implements ActionListener {
	//Instance variable
	JLabel lblWelcome,lblCardNumber,lblPinNumber;
	JTextField tfCardNumber;
	JPasswordField pfPinNumber;
	JButton btnLogin,btnClear,btnSingUp;
	
	
	//Non param Constructor
	public Login() {
		setTitle("Bank Management System");
		//To disable the default layout of frame 
		setLayout(null);
		
	lblWelcome=new JLabel("Welcome To Bank System");
	lblWelcome.setFont(new Font("Arial",Font.BOLD,35));
	lblWelcome.setBounds(200,40,530,40);
	add(lblWelcome);	
		
	lblCardNumber=new JLabel("Enter Card No:");
	lblCardNumber.setFont(new Font("Tahoma",Font.BOLD,25));
	lblCardNumber.setBounds(120,150,400,30);
	add(lblCardNumber);
	
	tfCardNumber=new JTextField(20);
	tfCardNumber.setBounds(400,150,230,30);
	tfCardNumber.setFont(new Font("Tahoma",Font.BOLD,15));
	add(tfCardNumber);
	
	lblPinNumber=new JLabel("Enter PIN Number:");
	lblPinNumber.setFont(new Font("Tahoma",Font.BOLD,25));
	lblPinNumber.setBounds(120,200,400,30);
	add(lblPinNumber);
	
	pfPinNumber=new JPasswordField(20);
	pfPinNumber.setBounds(400,200,230,30);
	pfPinNumber.setFont(new Font("Tahoma",Font.BOLD,15));
	add(pfPinNumber);
	
	btnLogin=new JButton("Login.");
	btnLogin.setBackground(Color.BLACK);
	btnLogin.setForeground(Color.WHITE);
	
	btnClear=new JButton("Clear");
	btnClear.setBackground(Color.BLACK);
	btnClear.setForeground(Color.WHITE);
			
	btnSingUp=new JButton("Sign Up.");
	btnSingUp.setBackground(Color.BLACK);
	btnSingUp.setForeground(Color.WHITE);
	
	btnLogin.setBounds(200,300,100,40);
	add(btnLogin);
	
	btnClear.setBounds(320,300,100,40);
	add(btnClear);
	
	btnSingUp.setFont(new Font("Tahoma",Font.BOLD,15));
	btnSingUp.setBounds(440,300,100,40);
	add(btnSingUp);
	
	btnLogin.addActionListener(this);
	btnClear.addActionListener(this);
	btnSingUp.addActionListener(this);
	
	
			
			
			
		//Changing the background color of Frame
		getContentPane().setBackground(Color.WHITE);
		setVisible(true);
		setSize(800, 450);
		setLocation(300, 150);
		
		
	}
	public static void main(String[] args) {
//Creating Login class object
		Login object=new Login();
		
	}
	
	//This method is automatically called when u click on any button
	@Override
	public void actionPerformed(ActionEvent ae) {
		try {
			if(ae.getSource()==btnLogin) {
				ConnectionFactory cf = new ConnectionFactory();
				String Card_Number=tfCardNumber.getText();
				String PIN_Number = pfPinNumber.getText();
				
				String query="Select*from Login where Card_Number='"+ Card_Number +"'and PIN_Number='"+PIN_Number+"'";
				ResultSet rs=cf.stmt.executeQuery(query);
				if(rs.next()) {
					setVisible(false);
					new Transaction(PIN_Number).setVisible(true);
					
				}
				else {
					JOptionPane.showMessageDialog(null, "Either Card_Number or PIN_Number is Wrong");
				}
			}
			else if(ae.getSource()==btnClear) {
				tfCardNumber.setText("");
				pfPinNumber.setText("");
			}
			else if(ae.getSource()==btnSingUp) {
				//This is For Sign Up Purpose
				this.setVisible(false);
				new Signup();
				
			}
		}
		catch(Exception e) {
			e.printStackTrace();
			
		}
		
	}

}
