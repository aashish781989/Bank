package bank;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import java.util.Date;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Deposit extends JFrame implements ActionListener{
    JTextField tf1, tf2;
    JButton b1, b2, b3;
    JLabel l1, l2, l3;

    String PIN_Number;

    // Parameterized Constructor
    public Deposit(String PIN_Number) {
        this.PIN_Number = PIN_Number;
        setSize(750, 780);
        setLocation(300, 0);
        

        setLayout(null);

        // ✅ Debugging ke liye Image Path Check
        URL imgURL = ClassLoader.getSystemResource("icons/atm.jpg");
        if (imgURL != null) {
            System.out.println("Image file found at: " + imgURL);
            ImageIcon i1 = new ImageIcon(imgURL);
            Image i2 = i1.getImage().getScaledInstance(750, 780, Image.SCALE_DEFAULT);
            ImageIcon i3 = new ImageIcon(i2);

            l3 = new JLabel(i3);
            l3.setBounds(0, 0, 750, 780);
            add(l3);
            setVisible(true);
            
            
            l1=new JLabel("Enter amount you want to deposit :-");
            l1.setForeground(Color.WHITE);
            l1.setFont(new Font("System",Font.BOLD,16));
            l1.setBounds(140, 270, 400, 35);
            l3.add(l1);
            
            tf1=new JTextField();
            tf1.setFont(new Font("Raleway", Font.BOLD,22));
            tf1.setBounds(140,310,280,25);
            l3.add(tf1);
            
            b1=new JButton("Deposit");
            b2=new JButton("Back");
            
            b1.setBounds(270,450,150,25);
            l3.add(b1);
            
            b2.setBounds(270, 490, 150, 25);
            l3.add(b2);
            
            b1.addActionListener(this);
            b2.addActionListener(this);
            
            
            
            
            
            
        } else {
            System.out.println("⚠ Image file not found. Check the path 'icons/atm.jpg'.");
        }
    }

    public static void main(String[] args) {
        new Deposit("");
    }

	@Override
	public void actionPerformed(ActionEvent ae) {
		try {
			String amount=tf1.getText();
			Date date=new Date();
			if(ae.getSource()==b1) {
				if(tf1.getText().equals("")) {
					JOptionPane.showConfirmDialog(null, "Please Enter Some Amount");
					
				}
				else 
				{
					ConnectionFactory cf=new ConnectionFactory();
					cf.stmt.executeUpdate("insert into bank values('"+PIN_Number+"','"+date+"','Deposit','"+amount+"')");
					JOptionPane.showMessageDialog(null, "Rs. "+amount+" Deposited Successfully");
					setVisible(false);
					new Transaction(PIN_Number).setVisible(true);
					
					
				}
			}
			else if(ae.getSource()==b2) {
				setVisible(false);
				new Transaction(PIN_Number).setVisible(true);
				
			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
}