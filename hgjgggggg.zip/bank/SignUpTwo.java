package bank;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.util.Random;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import com.toedter.calendar.JDateChooser;

public class SignUpTwo extends JFrame implements ActionListener {
	//Instance variable
	JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13,l14,l15;
	JTextField tfPan,tfAadhar;
	JRadioButton rbnCitizenYes,rbnCitizenNo,rbnAccountYes,rbnAccountNo,rbnUnmarried,rbnOthers;
	JComboBox jcbReligion,jcbCategory,jcbIncome,jcbEducation,jcbOccupation;
	JButton btnNext;
	
	String FormNo="";
	
	//Param Constructor
	public SignUpTwo(String FormNo) {
		this.FormNo=FormNo;
		setTitle("New Account Application Form-Page-2");
		setLayout(null);
		
		l2=new JLabel("Additional Details of Customer:");
		l2.setFont(new Font("Arial",Font.BOLD,25));
		l2.setBounds(230,80,600,30);
		add(l2);
		
		l3=new JLabel("Religion:");
		l3.setFont(new Font("Arial",Font.BOLD,20));
		l3.setBounds(100,130,200,30);
		add(l3);
		
		String[]religion= {"Hindu","Muslim","Sikh","Chritian","Other"};
		jcbReligion=new JComboBox(religion);
		jcbReligion.setBackground(Color.white);
		jcbReligion.setBounds(320,130,200,30);
		jcbReligion.setFont(new Font("Tahoma",Font.BOLD,14));
		add(jcbReligion);
		
		l4=new JLabel("Category:");
		l4.setFont(new Font("Arial",Font.BOLD,20));
		l4.setBounds(100,160,200,30);
		add(l4);
		
		String[]category= {"General","OBC","SC","ST","Other"};
		jcbCategory=new JComboBox(category);
		jcbCategory.setBackground(Color.white);
		jcbCategory.setBounds(320,160,200,30);
		jcbCategory.setFont(new Font("Tahoma",Font.BOLD,14));
		add(jcbCategory);
		
		l5=new JLabel("Income:");
		l5.setFont(new Font("Arial",Font.BOLD,20));
		l5.setBounds(100,190,600,30);
		add(l5);
		
		String[] income= {"Null","<1,50,000","<2,50,000","<5,00,000","Upto 10,00,000","Above 10,00,000"};
		jcbIncome=new JComboBox(income);
		jcbIncome.setBackground(Color.white);
		jcbIncome.setBounds(320,190,200,30);
		jcbIncome.setFont(new Font("Tahoma",Font.BOLD,14));
		add(jcbIncome);
		
		l6=new JLabel("Educational");
		l6.setFont(new Font("Arial",Font.BOLD,20));
		l6.setBounds(100,230,600,30);
		add(l6);
		l7=new JLabel("Qualification:");
		l7.setFont(new Font("Arial",Font.BOLD,20));
		l7.setBounds(100,250,200,30);
		add(l7);
		
		String education[]= {"Non-Graduate","Graduate","Post-Graduate","Doctors","Others"};
		jcbEducation=new JComboBox(education);
		jcbEducation.setBackground(Color.white);
		jcbEducation.setFont(new Font("Tahoma",Font.BOLD,14));
		jcbEducation.setBounds(320,240,200,30);
		add(jcbEducation);
		
		l8=new JLabel("Occupation:");
		l8.setFont(new Font("Arial",Font.BOLD,20));
		l8.setBounds(100,280,200,30);
		add(l8);
		
		String Occupation[]= {"Salaried","Self-Employed","Business","Student","Retured","Others"};
		jcbOccupation=new JComboBox(Occupation);
		jcbOccupation.setBackground(Color.white);
		jcbOccupation.setFont(new Font("Tahoma",Font.BOLD,14));
		jcbOccupation.setBounds(320,280,200,30);
		add(jcbOccupation);
		
		
		l9=new JLabel("Pan Number:");
		l9.setFont(new Font("Arial",Font.BOLD,20));
		l9.setBounds(100,310,600,30);
		add(l9);
		
		tfPan=new JTextField(20);
		tfPan.setBounds(320,310,200,30);
		tfPan.setFont(new Font("Tahoma",Font.BOLD,10));
		add(tfPan);
		
		l10=new JLabel("Aadhar Number:");
		l10.setFont(new Font("Arial",Font.BOLD,20));
		l10.setBounds(100,340,600,30);
		add(l10);
		
		tfAadhar=new JTextField(20);
		tfAadhar.setBounds(320,340,200,30);
		tfAadhar.setFont(new Font("Tahoma",Font.BOLD,10));
		add(tfAadhar);
		
		l11=new JLabel("Senior Citizen:");
		l11.setFont(new Font("Arial",Font.BOLD,20));
		l11.setBounds(100,370,600,30);
		add(l11);
		
		rbnCitizenYes=new JRadioButton("Yes");
		rbnCitizenYes.setFont(new Font("Tahoma",Font.BOLD,14));
		rbnCitizenYes.setBackground(Color.white);
		rbnCitizenYes.setBounds(310,370,50,30);
		add(rbnCitizenYes);
		
		rbnCitizenNo=new JRadioButton("No");
		rbnCitizenNo.setFont(new Font("Tahoma",Font.BOLD,14));
		rbnCitizenNo.setBackground(Color.white);
		rbnCitizenNo.setBounds(405,370,50,30);
		add(rbnCitizenNo);
		
		ButtonGroup bgCitizen=new ButtonGroup();
		bgCitizen.add(rbnCitizenYes);
		bgCitizen.add(rbnCitizenNo);
		
		
		l12=new JLabel("Exisiting Account:");
		l12.setFont(new Font("Arial",Font.BOLD,20));
		l12.setBounds(100,400,600,30);
		add(l12);
		
		rbnAccountYes=new JRadioButton("Yes");
		rbnAccountYes.setFont(new Font("Tahoma",Font.BOLD,14));
		rbnAccountYes.setBackground(Color.white);
		rbnAccountYes.setBounds(310,400,80,30);
		add(rbnAccountYes);
		
		rbnAccountNo=new JRadioButton("No");
		rbnAccountNo.setFont(new Font("Tahoma",Font.BOLD,14));
		rbnAccountNo.setBackground(Color.white);
		rbnAccountNo.setBounds(405,400,90,30);
		add(rbnAccountNo);
		
		ButtonGroup bgAccount=new ButtonGroup();
		bgAccount.add(rbnAccountYes);
		bgAccount.add(rbnAccountNo);
		
		
		btnNext=new JButton("Next");
		btnNext.setFont(new Font ("Arial",Font.BOLD,10));
		btnNext.setBackground(Color.black);
		btnNext.setForeground(Color.white);
		btnNext.setBounds(500,430,80,30);
		add(btnNext);
		btnNext.addActionListener(this);
		
		
		l13=new JLabel("Date:");
		l13.setFont(new Font("Arial",Font.BOLD,20));
		l13.setBounds(100,460,600,30);
		add(l13);
		
		l14=new JLabel("Month:");
		l14.setFont(new Font("Arial",Font.BOLD,20));
		l14.setBounds(100,490,600,30);
		add(l14);
		
		l15=new JLabel("Year:");
		l15.setFont(new Font("Arial",Font.BOLD,20));
		l15.setBounds(100,520,600,30);
		add(l15);
		
		
		getContentPane().setBackground(Color.white);
		setVisible(true);
		setSize(800,700);
		setLocation(400,100);
		
	}

	public static void main(String[] args) {
		SignUpTwo object=new SignUpTwo("");
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String Religion=(String) jcbReligion.getSelectedItem();
		String Category=(String) jcbCategory.getSelectedItem();
		String Income=(String) jcbIncome.getSelectedItem();
		String Education=(String) jcbEducation.getSelectedItem();
		String Occupation=(String) jcbOccupation.getSelectedItem();
		String Pan_Number=tfPan.getText();
		String Aadhar_Number=tfAadhar.getText();
		String scitizen="";
		if(rbnCitizenYes.isSelected()) {
			scitizen="Yes";
		}
		else if(rbnCitizenNo.isSelected()) {
			scitizen="No";
		}
		String eaccount="";
		if(rbnAccountYes.isSelected()) {
			eaccount="Yes";
		}
		else if(rbnAccountNo.isSelected()) {
			eaccount="No";
		}
		try {
			ConnectionFactory cf=new ConnectionFactory();
			String query="insert into SignUpTwo value('"+FormNo+"','"+Religion+"','"+Category+"','"+Income+"','"+Education+"','"+Occupation+"','"+Pan_Number+"','"+Aadhar_Number+"','"+scitizen+"','"+eaccount+"')";
			cf.stmt.executeUpdate(query);
			JOptionPane.showMessageDialog(btnNext, "Data Saved Successfully");
			new SignUpThree(FormNo).setVisible(true);
			setVisible(false);
		
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		
		
     
	}

}
